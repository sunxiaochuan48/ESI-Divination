# 跨平台迁移指南

本技能专为 AI 平台设计，核心价值在于**分析框架与推理逻辑**，而非特定平台实现。

---

## 各平台使用方式

### ZCode（主目标平台）

```
将 esi-tarot/ 目录放在 ZCode 技能搜索路径下：
  1. <project>/.zcode/skills/esi-tarot/SKILL.md
  2. ~/.zcode/skills/esi-tarot/SKILL.md

ZCode 自动发现 SKILL.md，通过 name: esi-tarot 注册。
用户通过 /esi-tarot <问题> 或技能匹配触发。
```

### 通用使用模式（任何 AI 聊天界面）

```
步骤 1：粘贴 SKILL.md 的内容作为系统提示
步骤 2：按执行流程，依次粘贴各 phases/ 文件
步骤 3：需要时查阅 knowledge/patterns.md
步骤 4：按 phases/ 中的指令完成分析

优点：不需要任何平台特性，纯提示工程。
```

---

## 跨平台能力矩阵

| 能力 | ZCode | Codex GPTs | Claude Code | 纯对话 |
|------|-------|-----------|-------------|--------|
| 自动发现注册 | ✅ | ❌ | ❌ | ❌ |
| 按需 Read 加载 | ✅ | ✅ (Knowledge) | ✅ | ❌ |
| 随机抽牌（脚本） | ✅ | ✅ (Python) | ✅ (bash) | ❌ (手动) |
| 完整自动解读 | ✅ | ✅ | ✅ | ❌ |
